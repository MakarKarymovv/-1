﻿//ДЗ №1 звучало так:
//Делаем калькулятор на любом из доступных вам ЯП, который решает СЛАУ (в т.ч. с космплексными коэффициентами).
//Используем метод Крамера для матриц 2х2, в идеале nхn
//Язык программирования: C#

using System.Numerics;
using System.Globalization;

class KramerSolver
{
    static void Main()
    {
        Console.WriteLine("Введите коэффициенты уравнений:");

        Complex a1 = ReadComplex("a1");
        Complex b1 = ReadComplex("b1");
        Complex c1 = ReadComplex("c1");

        Complex a2 = ReadComplex("a2");
        Complex b2 = ReadComplex("b2");
        Complex c2 = ReadComplex("c2");

        Complex D = a1 * b2 - a2 * b1;
        Complex Dx = c1 * b2 - c2 * b1;
        Complex Dy = a1 * c2 - a2 * c1;

        if (D == Complex.Zero)
            Console.WriteLine("Система не имеет единственного решения (D = 0).");
        else
        {
            Complex x = Dx / D;
            Complex y = Dy / D;
            Console.WriteLine($"Решение: x = {x}, y = {y}");
        }
    }

    static Complex ReadComplex(string name)
    {
        Console.Write($"{name} (пример: 3+4i): ");
        string input = Console.ReadLine();
        return ParseComplex(input);
    }

    static Complex ParseComplex(string input)
    {
        input = input.Replace("i", "").Replace("j", "");

        if (input.Contains("+") || input.Contains("-"))
        {
            input = input.Replace(" ", "");
            int index = input.LastIndexOfAny(new char[] { '+', '-' }, 1);
            if (index > 0)
            {
                string realPart = input.Substring(0, index);
                string imagPart = input.Substring(index);
                return new Complex(
                    double.Parse(realPart, CultureInfo.InvariantCulture),
                    double.Parse(imagPart, CultureInfo.InvariantCulture)
                );
            }
        }

        // Если одно число, то это либо чисто вещественное, либо чисто мнимое
        if (input.EndsWith("i") || input.EndsWith("j"))
            return new Complex(0, double.Parse(input.TrimEnd('i', 'j'), CultureInfo.InvariantCulture));
        else
            return new Complex(double.Parse(input, CultureInfo.InvariantCulture), 0);
    }
}
//Карымов Макар АТ-28